
from enum import Enum, auto
class IndexMode(Enum):
    BOOLEAN=auto()
    SMART_LTN= "SMART_LTN"
    SMART_LTC= "SMART_LTC"
    BM25=auto()
